<?php
defined('_JEXEC') or die('Direct access denied!');
$public='';
$private='';